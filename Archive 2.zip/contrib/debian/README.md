
Debian
====================
This directory contains files used to package plutuscoind/plutuscoin-qt
for Debian-based Linux systems. If you compile plutuscoind/plutuscoin-qt yourself, there are some useful files here.

## plutuscoin: URI support ##


plutuscoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install plutuscoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your plutuscoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/plutuscoin128.png` to `/usr/share/pixmaps`

plutuscoin-qt.protocol (KDE)

