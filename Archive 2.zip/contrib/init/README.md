Sample configuration files for:

SystemD: plutuscoind.service
Upstart: plutuscoind.conf
OpenRC:  plutuscoind.openrc
         plutuscoind.openrcconf
CentOS:  plutuscoind.init
OS X:    org.plutuscoin.plutuscoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
