<TS language="es_CO" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Click derecho para editar la dirección o etiqueta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Crear una nueva dirección</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nuevo</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copiar la dirección actualmente seleccionada al sistema de portapapeles</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>C&amp;errar</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Borrar la dirección actualmente seleccionada de la lista</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportar</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Borrar</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Diálogo de contraseña</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Poner contraseña</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nueva contraseña</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Repetir nueva contraseña</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>PlutuscoinGUI</name>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Sincronizando con la red...</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Nodo</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Mostrar vista general de la billetera</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transacciones</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>S&amp;alir</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Acerca de &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Mostrar información sobre Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Opciones</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Billetera Encriptada</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Billetera Copia de seguridad...</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Cambiar contraseña...</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Enviando Direcciones...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Recibiendo Direcciones...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Abrir &amp;URL...</translation>
    </message>
    <message>
        <source>Send coins to a Plutuscoin address</source>
        <translation>Enviando monedas a una dirección de Plutuscoin</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Cambiar la contraseña usando la encriptación de la billetera</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>&amp;Ventana desarrollador</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>Abrir consola de diagnóstico y desarrollo</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Verificar Mensaje...</translation>
    </message>
    <message>
        <source>Plutuscoin</source>
        <translation>Plutuscoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Billetera</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Enviar</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Recibir</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Mostrar / Ocultar</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Mostrar u ocultar la Ventana Principal</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Configuraciones</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Ayuda</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>bienvenido</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>plutuscoin-core</name>
    <message>
        <source>Plutuscoin Core</source>
        <translation>Plutuscoin Core</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Fondos Insuficientes</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Cargando billetera...</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>No se puede escribir la dirección por defecto</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Reescaneando</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Listo Cargando</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
</TS>
