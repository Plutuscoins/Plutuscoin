<TS language="ka" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>ახალი მისამართის შექმნა</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>შექმ&amp;ნა</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>მონიშნული მისამართის კოპირება სისტემურ კლიპბორდში</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;კოპირება</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>მონიშნული მისამართის წაშლა სიიდან</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>ამ ბარათიდან მონაცემების ექსპორტი ფაილში</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;ექსპორტი</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;წაშლა</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>ფრაზა-პაროლის დიალოგი</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>შეიყვანეთ ფრაზა-პაროლი</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>ახალი ფრაზა-პაროლი</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>გაიმეორეთ ახალი ფრაზა-პაროლი</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>PlutuscoinGUI</name>
    <message>
        <source>Sign &amp;message...</source>
        <translation>ხელ&amp;მოწერა</translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>ქსელთან სინქრონიზება...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>მიმ&amp;ოხილვა</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>კვანძი</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>საფულის ზოგადი მიმოხილვა</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;ტრანსაქციები</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>ტრანსაქციების ისტორიის დათვალიერება</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;გასვლა</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>გასვლა</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>&amp;Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>ინფორმაცია Qt-ს შესახებ</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;ოპციები</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>საფულის &amp;დაშიფრვა</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>საფულის &amp;არქივირება</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>ფრაზა-პაროლის შე&amp;ცვლა</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>გაგზავნის მი&amp;სამართი</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>მიღების მისამა&amp;რთი</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;URI-ის გახსნა...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>დისკზე ბლოკების რეინდექსაცია...</translation>
    </message>
    <message>
        <source>Send coins to a Plutuscoin address</source>
        <translation>მონეტების გაგზავნა Plutuscoin-მისამართზე</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>საფულის არქივირება სხვა ადგილზე</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>საფულის დაშიფრვის ფრაზა-პაროლის შეცვლა</translation>
    </message>
    <message>
        <source>&amp;Debug window</source>
        <translation>და&amp;ხვეწის ფანჯარა</translation>
    </message>
    <message>
        <source>Open debugging and diagnostic console</source>
        <translation>დახვეწისა და გიაგნოსტიკის კონსოლის გაშვება</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Plutuscoin</source>
        <translation>Plutuscoin</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>საფულე</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;გაგზავნა</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;მიღება</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;ჩვენება/დაფარვა</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>მთავარი ფანჯრის ჩვენება/დაფარვა</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>თქვენი საფულის პირადი გასაღებების დაშიფრვა</translation>
    </message>
    <message>
        <source>Sign messages with your Plutuscoin addresses to prove you own them</source>
        <translation>მესიჯებზე ხელმოწერა თქვენი Plutuscoin-მისამართებით იმის დასტურად, რომ ის თქვენია</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified Plutuscoin addresses</source>
        <translation>შეამოწმეთ, რომ მესიჯები ხელმოწერილია მითითებული Plutuscoin-მისამართით</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;ფაილი</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;პარამეტრები</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;დახმარება</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>ბარათების პანელი</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and plutuscoin: URIs)</source>
        <translation>გადახდის მოთხოვნა (შეიქმნება QR-კოდები და plutuscoin: ბმულები)</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>გამოყენებული გაგზავნის მისამართებისა და ნიშნულების სიის ჩვენება</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>გამოყენებული მიღების მისამართებისა და ნიშნულების სიის ჩვენება</translation>
    </message>
    <message>
        <source>Open a plutuscoin: URI or payment request</source>
        <translation>plutuscoin: URI-ის ან გადახდის მოთხოვნის გახსნა</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>საკომანდო სტრიქონის ოპ&amp;ციები</translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>ბლოკების წყარო მიუწვდომელია...</translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 და %2</translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 გავლილია</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>ბოლო მიღებული ბლოკის გენერირებიდან გასულია %1</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>შემდგომი ტრანსაქციები ნაჩვენები ჯერ არ იქნება.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>ინფორმაცია</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>განახლებულია</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>ჩართვა...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>გაგზავნილი ტრანსაქციები</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>მიღებული ტრანსაქციები</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>საფულე &lt;b&gt;დაშიფრულია&lt;/b&gt; და ამჟამად &lt;b&gt;განბლოკილია&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>საფულე &lt;b&gt;დაშიფრულია&lt;/b&gt; და ამჟამად &lt;b&gt;დაბლოკილია&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>რაოდენობა:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>ბაიტები:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>თანხა:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>პრიორიტეტი:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>საკომისიო:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>დამატებითი საკომისიო:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>ხურდა:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>ყველას მონიშვნა/(მოხსნა)</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>განტოტვილი</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>სია</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>თანხა</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>თარიღი</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>დადასტურება</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>დადასტურებულია</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>პრიორიტეტი</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>მისამართის შეცვლა</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>ნიშნუ&amp;ლი</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>მისამართების სიის ამ ჩანაწერთან ასოცირებული ნიშნული</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>მისამართების სიის ამ ჩანაწერთან მისამართი ასოცირებული. მისი შეცვლა შეიძლება მხოლოდ გაგზავნის მისამართის შემთხვევაში.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>მის&amp;ამართი</translation>
    </message>
    </context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>შეიქმნება ახალი მონაცემთა კატალოგი.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>კატალოგი უკვე არსებობს. დაამატეთ %1 თუ გინდათ ახალი კატალოგის აქვე შექმნა.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>მისამართი უკვე არსებობს და არ წარმოადგენს კატალოგს.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>კატალოგის აქ შექმნა შეუძლებელია.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>ვერსია</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>კომანდების ზოლის ოპციები</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>გამოყენება:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>კომანდების ზოლის ოპციები</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>მოგესალმებით</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>ნაგულისხმევი კატალოგის გამოყენება</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>მითითებული კატალოგის გამოყენება:</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    </context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI-ის გახსნა</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>გადახდის მოთხოვნის შექმნა URI-იდან ან ფაილიდან</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>გადახდის მოთხოვნის ფაილის არჩევა</translation>
    </message>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>ოპციები</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;მთავარი</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>მონაცემთა ბაზის კეშის სი&amp;დიდე</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>სკრიპტის &amp;ვერიფიცირების ნაკადების რაოდენობა</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>პროქსის IP-მისამართი (მაგ.: IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>საკომანდო სტრიქონის აქტიური ოპციები, რომლებიც გადაფარავენ ზემოთნაჩვენებს:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>კლიენტის ყველა პარამეტრის დაბრუნება ნაგულისხმევ მნიშვნელობებზე.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>დაბ&amp;რუნების ოპციები</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;ქსელი</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>ს&amp;აფულე</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction cannot be used until that transaction has at least one confirmation. This also affects how your balance is computed.</source>
        <translation>დაუდასტურებელი ხურდის გამოყენების აკრძალვის შემდეგ მათი გამოყენება შეუძლებელი იქნება, სანამ ტრანსაქციას არ ექნება ერთი დასტური მაინც. ეს აისახება თქვენი ნაშთის დათვლაზეც.</translation>
    </message>
    <message>
        <source>Automatically open the Plutuscoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>როუტერში Plutuscoin-კლიენტის პორტის ავტომატური გახსნა. მუშაობს, თუ თქვენს როუტერს ჩართული აქვს UPnP.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>პორტის გადამისამართება &amp;UPnP-ით</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>პროქსის &amp;IP:</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;პორტი</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>პროქსის პორტი (მაგ.: 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;ფანჯარა</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>ფანჯრის მინიმიზებისას მხოლოდ იკონა სისტემურ ზონაში</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;მინიმიზება სისტემურ ზონაში პროგრამების პანელის ნაცვლად</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>მ&amp;ინიმიზება დახურვისას</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>&amp;ჩვენება</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>სამომხმარებ&amp;ლო ენა:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>ერთეუ&amp;ლი:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>აირჩიეთ გასაგზავნი თანხის ნაგულისხმევი ერთეული.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>ვაჩვენოთ თუ არა მონეტების მართვის პარამეტრები.</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;გაუქმება</translation>
    </message>
    <message>
        <source>default</source>
        <translation>ნაგულისხმევი</translation>
    </message>
    <message>
        <source>none</source>
        <translation>ცარიელი</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>დაადასტურეთ პარამეტრების დაბრუნება ნაგულისხმევზე</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>ცვლილებები ძალაში შევა კლიენტის ხელახალი გაშვების შემდეგ.</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>ამ ცვლილებების ძალაში შესასვლელად საჭიროა კლიენტის დახურვა და ხელახალი გაშვება.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>პროქსის მისამართი არასწორია.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>ფორმა</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the Plutuscoin network after a connection is established, but this process has not completed yet.</source>
        <translation>ნაჩვენები ინფორმაცია შეიძლება მოძველებული იყოს. თქვენი საფულე ავტომატურად სინქრონიზდება Plutuscoin-ის ქსელთან კავშირის დამყარების შემდეგ, ეს პროცესი ჯერ არ არის დასრულებული.</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>ხელმისაწვდომია:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>თქვენი ხელმისაწვდომი ნაშთი</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>იგზავნება:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>დასადასტურებელი ტრანსაქციების საერთო რაოდენობა, რომლებიც ჯერ არ არის ასახული ბალანსში</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>მოუმზადებელია:</translation>
    </message>
    <message>
        <source>Mined balance that has not yet matured</source>
        <translation>მოპოვებული თანხა, რომელიც ჯერ არ არის მზადყოფნაში</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>სულ:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>თქვენი სრული მიმდინარე ბალანსი</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>თანხა</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 სთ</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 წთ</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>მიუწვდ.</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>N/A</source>
        <translation>მიუწვდ.</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>კლიენტის ვერსია</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;ინფორმაცია</translation>
    </message>
    <message>
        <source>Debug window</source>
        <translation>დახვეწის ფანჯარა</translation>
    </message>
    <message>
        <source>General</source>
        <translation>საერთო</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>სტარტის დრო</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>ქსელი</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>სახელი</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>შეერთებების რაოდენობა</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>ბლოკთა ჯაჭვი</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>ბლოკების მიმდინარე რაოდენობა</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>ბოლო ბლოკის დრო</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;შექმნა</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;კონსოლი</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;ქსელის ტრაფიკი</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;წაშლა</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>სულ:</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>შემომავალი:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>გამავალი:</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>დახვეწის ლოგ-ფაილი</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>კონსოლის გასუფთავება</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>კლავიშები "ზევით" და "ქვევით" - ისტორიაში მოძრაობა, &lt;b&gt;Ctrl-L&lt;/b&gt; - ეკრანის გასუფთავება.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>აკრიფეთ &lt;b&gt;help&lt;/b&gt; ფაშვებული ბრძანებების სანახავად.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>თ&amp;ანხა:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ნიშნუ&amp;ლი:</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;მესიჯი:</translation>
    </message>
    <message>
        <source>Reuse one of the previously used receiving addresses. Reusing addresses has security and privacy issues. Do not use this unless re-generating a payment request made before.</source>
        <translation>რომელიმე ადრე გამოყენებული მიღების მისამართის გამოყენება. ეს ამცირებს უსაფრთხოებასა და პრივატულობას. ნუ გამოიყენებთ ამ ოპციას, თუ არ ახდენთ ადრე მოთხოვნილი გადახდის ხელახლა გენერირებას.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>ად&amp;რე გამოყენებული მიღების მისამართის გამოყენება (არ არის რეკომენდებული)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the Plutuscoin network.</source>
        <translation>არააუცილებელი მესიჯი, რომელიც ერთვის გადახდის მოთხოვნას და ნაჩვენები იქნება მოთხოვნის გახსნისას. შენიშვნა: მესიჯი არ გაყვება გადახდას ბითქოინის ქსელში.</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>არააუცილებელი ნიშნული ახალ მიღების მისამართთან ასოცირებისათვის.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>გამოიყენეთ ეს ფორმა გადახდის მოთხოვნისათვის. ყველა ველი &lt;b&gt;არააუცილებელია&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>მოთხოვნის მოცულობა. არააუცილებელია. ჩაწერეთ 0 ან დატოვეთ ცარიელი, თუ არ მოითხოვება კონკრეტული მოცულობა.</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ფორმის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>წაშლა</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>მოთხოვნილი გადახდების ისტორია</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;გადახდის მოთხოვნა</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>არჩეული მოთხოვნის ჩვენება (იგივეა, რაც ჩანაწერზე ორჯერ ჩხვლეტა)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>ჩვენება</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>მონიშნული ჩანაწერების წაშლა სიიდან</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>წაშლა</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-კოდი</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>&amp;URI-ის კოპირება</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>მის&amp;ამართის კოპირება</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>გამო&amp;სახულების შენახვა...</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>მონეტების გაგზავნა</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>მონეტების კონტროლის პარამეტრები</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>ხარჯები...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>არჩეულია ავტომატურად</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>არ არის საკმარისი თანხა!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>რაოდენობა:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>ბაიტები:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>თანხა:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>პრიორიტეტი:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>საკომისიო:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>დამატებითი საკომისიო:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>ხურდა:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>ამის გააქტიურებისას თუ ხურდის მისამართი ცარიელია ან არასწორია, ხურდა გაიგზავნება ახლად გენერირებულ მისამართებზე.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>ხურდის მისამართი</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>ტრანსაქციის საფასური - საკომისიო:</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>გაგზავნა რამდენიმე რეციპიენტთან ერთდროულად</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>&amp;რეციპიენტის დამატება</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>ფორმის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>გ&amp;ასუფთავება</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>ბალანსი:</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>გაგზავნის დადასტურება</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>გაგ&amp;ზავნა</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;რაოდენობა</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>ადრესა&amp;ტი:</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>ნიშნუ&amp;ლი:</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>აირჩიეთ ადრე გამოყენებული მისამართი</translation>
    </message>
    <message>
        <source>This is a normal payment.</source>
        <translation>ეს არის ჩვეულებრივი გადახდა.</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>მისამართის ჩასმა კლიპბორდიდან</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>ჩანაწერის წაშლა</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>მესიჯი:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>შეიყვანეთ ამ მისამართის ნიშნული გამოყენებული მისამართების სიაში დასამატებლად</translation>
    </message>
    <message>
        <source>A message that was attached to the plutuscoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the Plutuscoin network.</source>
        <translation>მესიჯი, რომელიც თან ერთვის მონეტებს:  URI, რომელიც შეინახება ტრანსაქციასთან ერთად თქვენთვის. შენიშვნა: მესიჯი არ გაყვება გადახდას ბითქოინის ქსელში.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>ადრესატი:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>შენიშვნა:</translation>
    </message>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>არ გამორთოთ კომპიუტერი ამ ფანჯრის გაქრობამდე.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>ხელმოწერები - მესიჯის ხელმოწერა/ვერიფიკაცია</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>მე&amp;სიჯის ხელმოწერა</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>აირჩიეთ ადრე გამოყენებული მისამართი</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>მისამართის ჩასმა კლიპბორდიდან</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>აკრიფეთ ხელმოსაწერი მესიჯი</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>ხელმოწერა</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>მიმდინარე ხელმოწერის კოპირება კლიპბორდში</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this Plutuscoin address</source>
        <translation>მოაწერეთ ხელი იმის დასადასტურებლად, რომ ეს მისამართი თქვენია</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;მესიჯის ხელმოწერა</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>ხელმოწერის ყველა ველის წაშლა</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>გ&amp;ასუფთავება</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>მესიჯის &amp;ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified Plutuscoin address</source>
        <translation>შეამოწმეთ, რომ მესიჯი ხელმოწერილია მითითებული Plutuscoin-მისამართით</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;მესიჯის ვერიფიკაცია</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>ვერიფიკაციის ყველა ველის წაშლა</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>ტრანსაქციის დაწვრილებითი აღწერილობა</translation>
    </message>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>plutuscoin-core</name>
    <message>
        <source>Options:</source>
        <translation>ოპციები:</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>მიუთითეთ მონაცემთა კატალოგი</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>მიერთება კვანძთან, პირების მისამართების მიღება და გათიშვა</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>მიუთითეთ თქვენი საჯარო მისამართი</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>საკომანდო სტრიქონისა და JSON-RPC-კომამდების ნებართვა</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>რეზიდენტულად გაშვება და კომანდების მიღება</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>გარედან შეერთებების დაშვება (ნაგულისხმევი: 1 თუ არ გამოიყენება -proxy ან -connect)</translation>
    </message>
    <message>
        <source>Plutuscoin Core</source>
        <translation>Plutuscoin Core</translation>
    </message>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>მოცემულ მისამართზე მიჯაჭვა მუდმივად მასზე მიყურადებით. გამოიყენეთ [host]:port ფორმა IPv6-სათვის</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>კომანდის შესრულება საფულის ტრანსაქციის ცვლილებისას (%s კომანდაში ჩანაცვლდება TxID-ით)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>ეს არის წინასწარი სატესტო ვერსია - გამოიყენეთ საკუთარი რისკით - არ გამოიყენოთ მოპოვებისა ან კომერციული მიზნებისათვის</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>ყურადღება: ქსელში შეუთანხმებლობაა. შესაძლოა ცალკეულ მომპოვებლებს პრობლემები ექმნებათ!</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>ყურადღება: ჩვენ არ ვეთანხმებით ყველა პირს. შესაძლოა თქვენ ან სხვა კვანძებს განახლება გჭირდებათ.</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:</source>
        <translation>&lt;category&gt; შეიძლება იყოს:</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>ბლოკის შექმნის ოპციები:</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>შეერთება მხოლოდ მითითებულ კვანძ(ებ)თან</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>შენიშნულია ბლოკთა ბაზის დაზიანება</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>არ ჩაიტვირთოს საფულე და აიკრძალოს საფულისადმი RPC-მიმართვები</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>გავუშვათ ბლოკთა ბაზის ხელახლა აგება ეხლა?</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>ვერ ინიციალიზდება ბლოკების ბაზა</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>ვერ ინიციალიზდება საფულის ბაზის გარემო %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>არ იტვირთება ბლოკების ბაზა</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>ბლოკთა ბაზის შექმნა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>შეცდომა: დისზე არ არის ადგილი!</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>ვერ ხერხდება პორტების მიყურადება. თუ გსურთ, გამოიყენეთ -listen=0.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>საწყისი ბლოკი არ არსებობს ან არასწორია. ქსელის მონაცემთა კატალოგი datadir ხომ არის არასწორი?</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>არასწორია მისამართი -onion: '%s'</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>არ არის საკმარისი ფაილ-დესკრიპტორები.</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>ბლოკის მაქსიმალური ზომის განსაზღვრა ბაიტებში (ნადულისხმევი: %d)</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>მიუთითეთ საფულის ფაილი (კატალოგში)</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>ბლოკების ვერიფიკაცია...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>საფულის ვერიფიკაცია...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>საფულე %s მდებარეობს მონაცემთა კატალოგის %s გარეთ</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>სფულის ოპციები:</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>ბრძანების შესრულება შესაბამისი უწყების მიღებისას ან როცა შეინიშნება საგრძნობი გახლეჩა (cmd-ში %s შეიცვლება მესიჯით)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>მაღალპრიორიტეტული/დაბალსაკომისიოიანი ტრანსაქციების მაქსიმალური ზომა ბაიტებში (ნაგულისხმევი: %d)</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>ინფორმაცია</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>ტრასირების/დახვეწის ინფოს გაგზავნა კონსოლზე debug.log ფაილის ნაცვლად</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>debug.log ფაილის შეკუმშვა გაშვებისას (ნაგულისხმევია: 1 როცა არ აყენია -debug)</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>ტრანსაქციების ხელმოწერა ვერ მოხერხდა</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>ტრანსაქციების რაოდენობა ძალიან ცოტაა</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>ტრანსაქციების რაოდენობა დადებითი რიცხვი უნდა იყოს</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>ტრანსაქცია ძალიან დიდია</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>მომხმარებლის სახელი JSON-RPC-შეერთებისათვის</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>გაფრთხილება</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>ტრანსაქციების ჩახსნა საფულიდან...</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>პაროლი JSON-RPC-შეერთებისათვის</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>კომანდის შესრულება უკეთესი ბლოკის გამოჩენისას (%s კომანდაში ჩანაცვლდება ბლოკის ჰეშით)</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>DNS-ძებნის დაშვება -addnode, -seednode და -connect-სათვის</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>მისამართების ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>არასწორია მისამართი -proxy: '%s'</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>-onlynet-ში მითითებულია უცნობი ქსელი: '%s'</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>არ არის საკმარისი თანხა</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>ბლოკების ინდექსის ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>მისაერთებელი კვანძის დამატება და მიერთების შეძლებისდაგვარად შენარჩუნება</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>საფულის ჩატვირთვა...</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>საფულის ძველ ვერსიაზე გადაყვანა შეუძლებელია</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>ვერ ხერხდება ნაგულისხმევი მისამართის ჩაწერა</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>სკანირება...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>ჩატვირთვა დასრულებულია</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
</context>
</TS>
